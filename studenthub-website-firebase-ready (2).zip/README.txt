# StudentHub Student Portal

This is a ready-to-deploy student opportunity website.

Included:
- Software Development Internship
- Government Scholarship
- Data Science Course
- Engineering Internship
- Login button
- Sign Up button
- Firebase Email/Password Authentication
- Responsive mobile design

## Firebase setup

1. Go to Firebase Console.
2. Create/select your project.
3. Add a Web App.
4. Copy the Firebase configuration.
5. Open `app.js`.
6. Replace the values inside `firebaseConfig`.
7. In Firebase Console:
   Authentication -> Sign-in method -> Email/Password -> Enable.
8. Deploy the folder.

Important: Firebase Web configuration values are normally safe to place in frontend code. Security should be enforced with Firebase Authentication and Firestore/Storage Security Rules if you later add private student data.

## Cloudflare

You can upload/deploy these files to your existing Cloudflare project. If using Wrangler, make sure your Cloudflare Worker/static-assets configuration matches your project setup.
